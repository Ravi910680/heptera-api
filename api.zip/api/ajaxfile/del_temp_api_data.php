<?php


session_start();

$id=$_SESSION['id'];
require("../confige/heptera_api_conn.php");

$temp_id=$_POST['temp_id'];


if(isset($id)){

$sel_temp_data="delete from `heptera-api-temp` where temp_id='$temp_id'";

if(unlink("../api_temp/".$temp_id.".php")){

if($heptera_api_conn->query($sel_temp_data)=="TRUE"){

echo 1;

}else{
	echo 0;
}





}else{
	echo 0;
}
}


?>