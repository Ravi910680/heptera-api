<?php
session_start();


require("../confige/send_api_table_conn.php");
require("../confige/fileconfige.php");

$id='16';



function init_lst_data($conn,$id){

$ret_arr=array();

$sel_all_lst_dt="select * from `filedetails` where id='$id'";



$result_lst_dt=$conn->query($sel_all_lst_dt);

if ($result_lst_dt->num_rows > 0) {
  // output data of each row
  while($row = $result_lst_dt->fetch_assoc()) {

$ret_arr[$row['filename']]=base64_decode(explode("^", $row['filename'])[1]);



    
  }

  return $ret_arr;
} else {
  return 0;
}


}






function get_email_data($conn,$lst_id,$con_id,$query){


$sel_dt_email='select * from `'.$lst_id.'` where con_id="'.$con_id.'"'.$query;


$result_lst_dt=$conn->query($sel_dt_email);



if ($result_lst_dt->num_rows > 0) {
  // output data of each row
  while($row = $result_lst_dt->fetch_assoc()) {



return $row['email'];


    
  }

  
} 



}


function get_list_table_query($email){
  return " email LIKE '%".$email."%'";

}

function get_hist_table_query($jsn_data,$id){

if($jsn_data[0]=='lst_id'){
  $jsn_data[1]=$id."^".base64_encode($jsn_data[1]);
}

return " where ".$jsn_data[0]." LIKE '%".$jsn_data[1]."%'";


}


$send_token=$_POST['token'];

$get_query_for_hist_tbl="";

$get_query_for_list_table="";

if(strlen($_POST['src_data'])==2){



$sel_all_data_query="select * from `$send_token`";
}else{


$json_dec_dt=json_decode($_POST['src_data']);

if($json_dec_dt[0]=='con_id'){

$get_query_for_hist_tbl="";

$get_query_for_list_table=get_list_table_query($json_dec_dt[1]);

}else{

$get_query_for_list_table="";

$get_query_for_hist_tbl=get_hist_table_query($json_dec_dt,$id);

}

$sel_all_data_query="select * from `$send_token`".$get_query_for_hist_tbl;


}






$lst_data=init_lst_data($conn2,$id);


$geted_res=array();

if($lst_data==0){


}else{

$result=$send_api_table_conn->query($sel_all_data_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


$lst_id_def=$row['lst_id'];

$con_id_def=$row['con_id'];

$row['email']=get_email_data($conn3,$lst_id_def,$con_id_def,$get_query_for_list_table);


$row['lst_name']=$lst_data[$lst_id_def];

array_push($geted_res, $row);

  }
} else {
  echo 0;
}

}


print_r(json_encode($geted_res));

?>